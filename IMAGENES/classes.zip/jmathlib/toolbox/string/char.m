function x=char(y)

x=_char(y);

endfunction

/*
@GROUP
char
@SYNTAX
char(number)
@DOC
external function for changing numbers into strings
@NOTES
@EXAMPLES
@SEE
blanks, deblank
*/