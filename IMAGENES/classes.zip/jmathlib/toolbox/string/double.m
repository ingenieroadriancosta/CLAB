function x=double(y)

x=_double(y);

endfunction

/*
@GROUP
char
@SYNTAX
double(char)
@DOC
external function for changing strings into numbers
@NOTES
@EXAMPLES
@SEE
blanks, deblank, char
*/