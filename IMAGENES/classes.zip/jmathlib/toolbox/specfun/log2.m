function [f, e] = log2 (x)



    f = log(x) / log(2);
 
endfunction

