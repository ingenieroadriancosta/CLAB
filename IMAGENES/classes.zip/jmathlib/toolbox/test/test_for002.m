
for x=[1,4,7]
	disp(x)
    disp(x+2)
end;
	
    
    
    
    
    
