
function x=testFunction002(y)

x=22;

endfunction