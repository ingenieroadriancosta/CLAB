function y=testFunction001(x)

y=1;

if (x>1),
y=7+x;
end
