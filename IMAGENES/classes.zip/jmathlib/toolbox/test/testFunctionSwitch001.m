function t=test_switch(x)
	switch(x)
		case(1):
        {
			t=1;		
		}
        case(2):
		{
        	t=2;
        }
	end;


