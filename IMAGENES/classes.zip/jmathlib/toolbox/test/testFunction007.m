function [y,x]=testFunction007(a,b,c,varargin)

x=0

z=size(varargin)

y=z(1)
x=z(2)
    
endfunction