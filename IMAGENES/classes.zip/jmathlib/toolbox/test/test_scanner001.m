# test handling of ...

a=6;
b=7;
a=b ...
+4


# a supposed to be 10 now