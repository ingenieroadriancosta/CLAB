

	switch(x) 
	case(1) y=123;	
	case(2) {y=234; } 
	case(3) y=345;
	default y=777; 
	endswitch;
