function x=testFunction006a(a)
x= a + 2;
