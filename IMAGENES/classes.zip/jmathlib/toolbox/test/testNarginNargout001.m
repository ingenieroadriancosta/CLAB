function testFunctionNarginNargout001(a,b,c,d)

disp("test of number of inputs and outputs \n");

disp("nargin  = "+ nargin);
disp("nargout = "+ nargout);

endfunction

