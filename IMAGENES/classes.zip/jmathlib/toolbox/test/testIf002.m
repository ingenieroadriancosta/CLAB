y=1;
x=2;

disp("start")
if(4<3) a=11; elseif (2<3) { a=22;} else {a=33;} endif
disp("end")
disp(a);
