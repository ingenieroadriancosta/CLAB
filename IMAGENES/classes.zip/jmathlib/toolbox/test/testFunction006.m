function [x,y]=testFunction006(a)
x=testFunction006a(a);
y=testFunction006b(a);
