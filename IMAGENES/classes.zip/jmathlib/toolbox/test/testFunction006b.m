function x=testFunction006a(a)
x= 3*a;
