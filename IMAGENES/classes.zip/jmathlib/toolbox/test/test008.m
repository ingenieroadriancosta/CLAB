function [a,b,c]=asdfasdf(g,h,k,l)

who()
a=g;

who()