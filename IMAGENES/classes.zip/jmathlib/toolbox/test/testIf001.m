y=1;
x=2;

disp("start")
if (x>1)
y=7+x;
endif
disp("end")
