function x=testFunction004(a,b)
x=a+2*b;
