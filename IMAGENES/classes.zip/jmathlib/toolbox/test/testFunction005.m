function [x,y]=testFunction005(a,b)
x=a+2*b;
y=2*a+b;
