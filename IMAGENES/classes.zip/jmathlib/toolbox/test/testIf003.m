
if(4<3)a=33; else a=44; b=33; endif

disp(a)