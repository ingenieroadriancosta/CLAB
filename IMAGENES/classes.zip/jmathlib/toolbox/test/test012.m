function test012(b)

global c
c=b+1;

whos

endfunction
