
s='asdf sdfg';

k = find(5 )

disp('k= '+k)
