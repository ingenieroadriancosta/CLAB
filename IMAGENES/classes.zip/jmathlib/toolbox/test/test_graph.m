FUNCTION t=test_graph()
	plotfunction("sin", 0, 8, "b");
	hold(1);
	plotfunction("cos", 0, 8, "g");
	t=1;
    
    
/*
@GROUP
test
@SYNTAX
TEST_Graph()
@DOC
A function to test basic graph drawing.
@NOTES
@EXAMPLES
TEST_Graph()
@SEE
*/
    
