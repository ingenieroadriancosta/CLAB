
for x=2:2:8
	disp(x)

end;
	
    
    
    
    
    
