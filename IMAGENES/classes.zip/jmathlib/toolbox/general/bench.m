


tic;

a=linspace(0,100,100);



toc

/*
@GROUP
general
@SYNTAX
bench
@DOC
this runs a benchmark test on the current machine
@NOTES
@EXAMPLES
<programlisting>
bench
</programlisting>
@SEE
*/