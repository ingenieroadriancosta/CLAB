function x=class(y)

x=_class(y);

endfunction