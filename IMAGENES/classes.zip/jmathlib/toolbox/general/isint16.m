function y = isint16(x)

y = isa(x, 'int16');

endfunction

/*
@GROUP
general
@SYNTAX
isint16(x)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
.
@SEE
ischar, iscell, isnumeric, ismatrix, isprime
*/

