function y = isdouble(x)

y = isa(x, 'double');

endfunction

/*
@GROUP
general
@SYNTAX
isdouble(x)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
.
@SEE
ischar, iscell, isnumeric, ismatrix, isprime
*/

