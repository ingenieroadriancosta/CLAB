# return number of elements
function n = numel(arg)

b=size(arg);

n=b(1)*b(2);

endfunction