
/*
@GROUP
ftp
@SYNTAX
ftp('server')
@DOC
Opens an ftp connection. 
THIS FUNCTION IS NOT YET IMPLEMENTED
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE
urlread
*/
