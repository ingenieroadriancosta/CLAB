# demo for JMathLib

disp("Hello this is a demo of JMathLib")
pause(1)

disp("Hello");
pause(1);
disp("Hello this ");
pause(1);
disp("Hello this is");
pause(1);
disp("Hello this is a");
pause(1);
disp("Hello this is a demo");
pause(1);
disp("Hello this is a demo of");
pause(1);
disp("Hello this is a demo of JMathLib");
pause(1);

plot(rand(2,20))
pause(1)

subplot(2,2,1);
plot(rand(2,29));
grid(1);

subplot(2,2,2);
plot([1:29],rand(1,29),'g');
grid(1);
hold(1);
pause(1);
plot([1:20],rand(1,20),'b');

