hello=1;
bar=2;
foo=[1,2,3];
