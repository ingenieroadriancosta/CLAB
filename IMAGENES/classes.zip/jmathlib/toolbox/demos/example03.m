if(a>2){b=1;}else{b=2;}

if(aa>2)
{
  bb=1;
}
else
{
 bb=2;}
