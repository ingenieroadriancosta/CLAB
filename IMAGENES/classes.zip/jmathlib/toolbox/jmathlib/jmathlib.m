

/*
@GROUP
jmathlib
@SYNTAX
jmathlib
@DOC
JMathLib is a great tool. It works like Matlab, Freemat, Octave, Scilab, but it 
is written completely in java
@EXAMPLES
.
@NOTES
@SEE
matlab, scilab, freemat, octave
*/

