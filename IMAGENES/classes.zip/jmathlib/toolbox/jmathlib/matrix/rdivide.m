function C=rdivide(A,B)

C=A./B;

/*
@GROUP
Matrix
@SYNTAX
rdivide(A,B)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE
mldivide, mrdivide
*/