function C=gt(A,B)

C=(A>B);


/*
@GROUP
Matrix
@SYNTAX
gt(A,B)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE
eq, ge, lt, le, ne
*/