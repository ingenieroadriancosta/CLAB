function C=ne(A,B)

C=(A~=B);


/*
@GROUP
Matrix
@SYNTAX
ne(A,B)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE
eq, ge, gt, lt, le
*/