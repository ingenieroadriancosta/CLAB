function C=uplus(A)

C=+A;

/*
@GROUP
Matrix
@SYNTAX
uplus(A)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE
plus, minus, uminus
*/