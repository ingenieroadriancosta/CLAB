function C=inv(A)

C=inversematrix(A);


/*
@GROUP
Matrix
@SYNTAX
inv(A)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE

*/