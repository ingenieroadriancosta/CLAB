function C=power(A,B)

C=A.^B;


/*
@GROUP
Matrix
@SYNTAX
power(A,B)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE

*/