function C=ctranspose(A)

C=A';


/*
@GROUP
matrix
@SYNTAX
answer = template (value)
@DOC
.
@EXAMPLES
.
@NOTES
.
@SEE
transpose
*/