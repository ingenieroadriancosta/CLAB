function C=transpose(A)

C=A.';

endfunction

/*
@GROUP
matrix
@SYNTAX
transpose(A)
@DOC
.
@EXAMPLES
.
@NOTES
C=A.'
@SEE
ctranspose
*/