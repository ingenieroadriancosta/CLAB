function C=eq(A,B)

C=(A==B);


/*
@GROUP
Matrix
@SYNTAX
eq(A,B)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE
ge, gt, lt, le, ne
*/