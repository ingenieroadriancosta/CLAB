function C=ge(A,B)

C=(A>=B);


/*
@GROUP
Matrix
@SYNTAX
ge(A,B)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE
eq, gt, lt, le, ne
*/