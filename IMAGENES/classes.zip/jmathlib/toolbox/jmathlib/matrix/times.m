function C=times(A,B)

C=A.*B;


/*
@GROUP
matrix
@SYNTAX
C=times(A,B)
@DOC
.
@EXAMPLES
.
@NOTES
.
@SEE

*/
