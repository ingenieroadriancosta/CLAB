function C=ldivide(A,B)

C=A.\B;


/*
@GROUP
Matrix
@SYNTAX
ldivide(A,B)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE

*/