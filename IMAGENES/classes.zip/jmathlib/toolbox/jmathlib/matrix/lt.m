function C=lt(A,B)

C=(A<B);


/*
@GROUP
Matrix
@SYNTAX
lt(A,B)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE
eq, ge, gt, le, ne
*/