function C=mrdivide(A,B)

C=A/B;

/*
@GROUP
Matrix
@SYNTAX
mrdivide(A,B)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE
mldivide
*/