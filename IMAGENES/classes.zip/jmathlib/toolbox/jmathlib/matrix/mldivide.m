function C=mldivide(A,B)

C=A\B;


/*
@GROUP
Matrix
@SYNTAX
mldivide(A,B)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE
mrdivide
*/