function C=minus(A,B)

C=A-B;

/*
@GROUP
Matrix
@SYNTAX
minus(A,B)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE

*/