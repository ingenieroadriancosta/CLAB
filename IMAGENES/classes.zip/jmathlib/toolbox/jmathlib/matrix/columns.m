function nc=columns(A)

s=size(A);
nc=s(2);

endfunction


/*
@GROUP
matrix
@SYNTAX
answer = columns (value)
@DOC
.
@EXAMPLES
.
@NOTES
.
@SEE
col, row, rows
*/