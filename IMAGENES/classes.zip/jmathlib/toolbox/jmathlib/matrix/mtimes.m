function C=mtimes(A,B)

C=A*B;

/*
@GROUP
Matrix
@SYNTAX
mtimes(A,B)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE
plus, minus
*/