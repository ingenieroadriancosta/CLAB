function C=uminus(A)

C=-A;

/*
@GROUP
Matrix
@SYNTAX
uminus(A)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE
plus, minus
*/