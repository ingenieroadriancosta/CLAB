function C=mpower(A,B)

C=A^B;


/*
@GROUP
Matrix
@SYNTAX
mpower(A,B)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE

*/