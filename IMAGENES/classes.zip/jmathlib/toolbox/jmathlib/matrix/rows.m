function nr=rows(A)

s=size(A);
nr=s(1);

endfunction

/*
@GROUP
Matrix
@SYNTAX
rows(A)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE
row, col, columns
*/