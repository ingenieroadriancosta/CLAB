function C=det(A)

C=determinant(A);


/*
@GROUP
Matrix
@SYNTAX
det(A)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE

*/