function C=plus(A,B)

C=A+B;


/*
@GROUP
Matrix
@SYNTAX
plus(A,B)
@DOC
.
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE

*/
