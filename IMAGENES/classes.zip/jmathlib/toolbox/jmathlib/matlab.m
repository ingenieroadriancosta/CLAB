

/*
@GROUP
jmathlib
@SYNTAX
matlab
@DOC
Matlab is a great tool. JMathLib is a clone of Matlab, but written 100% in java.
@EXAMPLES
.
@NOTES
@SEE
jmathlib, scilab, freemat, octave
*/

