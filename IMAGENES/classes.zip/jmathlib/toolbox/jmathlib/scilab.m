

/*
@GROUP
jmathlib
@SYNTAX
scilab
@DOC
Scilab is a great tool. JMathLib is a clone of Scilab, but written 100% in java.
@EXAMPLES
.
@NOTES
@SEE
jmathlib, matlab, freemat, octave
*/

