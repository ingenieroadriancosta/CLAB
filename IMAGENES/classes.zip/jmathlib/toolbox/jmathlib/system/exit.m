function exit()

quit();

/*
@GROUP
system
@SYNTAX
exit
@DOC
exits JMathLib
@EXAMPLE
<programlisting>
exit
</programlisting>
@NOTES
.
@SEE
quit
*/
