

/*
@GROUP
jmathlib
@SYNTAX
freemat
@DOC
Freemat is a great tool. JMathLib is a clone of Freemat, but written 100% in java.
@EXAMPLES
.
@NOTES
@SEE
jmathlib, matlab, scilab, octave
*/

