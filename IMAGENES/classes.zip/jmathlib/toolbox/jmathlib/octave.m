

/*
@GROUP
jmathlib
@SYNTAX
octave
@DOC
Octave is a great tool. JMathLib is a clone of Octave, but written 100% in java.
@EXAMPLES
.
@NOTES
@SEE
jmathlib, matlab, freemat, scilab
*/

