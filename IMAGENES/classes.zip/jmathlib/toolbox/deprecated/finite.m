function y = finite(x)

y = isfinite(x);
disp('isfinite: is deprecated')
endfunction

/*
@GROUP
deprecated
@SYNTAX
finite(x);
@DOC
this function is deprecated.
@EXAMPLES
<programlisting>
isfinite(x)
</programlisting>
@NOTES
@SEE
isfinite
*/