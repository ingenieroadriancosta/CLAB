
/*
@GROUP
engine
@SYNTAX
engine
@DOC
this is the basic command for using the "engine" of JMathLib
@EXAMPLES
<programlisting>
</programlisting>
@NOTES
@SEE
*/
